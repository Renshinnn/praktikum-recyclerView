package www.smktelkommlg.sch.recylcerview

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.annotation.NonNull
import androidx.recyclerview.widget.RecyclerView
internal class GameAdapter(private var sepedaList: List<ModelGame>) :
    RecyclerView.Adapter<GameAdapter.MyViewHolder>() {
    internal inner class MyViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        var nama: TextView = view.findViewById(R.id.rlMain)
        var dev: TextView = view.findViewById(R.id.recyclerView)
    }
    @NonNull
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val itemView = LayoutInflater.from(parent.context)
            .inflate(R.layout.activity_main, parent, false)
        return MyViewHolder(itemView)
    }
    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val sepeda = sepedaList[position]
        holder.nama.text = sepeda.getNama()
        holder.dev.text = sepeda.getDev()
    }
    override fun getItemCount(): Int {
        return sepedaList.size
    }
}