package www.smktelkommlg.sch.recylcerview

import android.icu.text.CaseMap
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.util.ArrayList

class MainActivity : AppCompatActivity() {
    private val gameList = ArrayList<ModelGame>()
    private lateinit var gameAdapter: GameAdapter
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        CaseMap.Title = "List Game"
        val recyclerView: RecyclerView = findViewById(R.id.recyclerView)
        gameAdapter = GameAdapter(gameList)
        val layoutManager = LinearLayoutManager(applicationContext)
        recyclerView.layoutManager = layoutManager
        recyclerView.itemAnimator = DefaultItemAnimator
        recyclerView.adapter = gameAdapter
        prepareDataGame()
    }
    private fun prepareDataGame(){
        var game = ModelGame("Mobile Legends: Bang Bang", "Moonton")
        gameList.add(game)
        game = ModelGame("eFootball 2021", "Konami")
        gameList.add(game)
        game = ModelGame("League of Legends: Wild Rift", "Riot Games")
        gameList.add(game)
        game = ModelGame("Sepak Bola FIFA", "ELECTRONIC ARTS")
        gameList.add(game)
        game = ModelGame("Garena Free Fire - Illuminate", "Garena International")
        gameList.add(game)
        game = ModelGame("Apex Legends Mobile", "ELECTRONIC ARTS")
        gameList.add(game)
        game = ModelGame("PUBG MOBILE: Aftermath", "Level Infinate")
        gameList.add(game)
        game = ModelGame("Call of Duty: Mobile", "Garena Mobile Private")
        gameList.add(game)
        game = ModelGame("LifeAfter", "NetEase Games")
        gameList.add(game)
        game = ModelGame("Clash of Clans", "Supercell")
        gameList.add(game)
        game = ModelGame("Clash Royale", "Supercell")
        gameList.add(game)
        game = ModelGame("Genshin Impact", "COGNOSPHERE PTE. LTD.")
        gameList.add(game)
        game = ModelGame("Mafia City", "YOTTA GAMES")
        gameList.add(game)

        gameAdapter.notifyDataSetChanged()
    }
}