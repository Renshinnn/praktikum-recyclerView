package www.smktelkommlg.sch.recylcerview

class ModelGame(nama: String?, dev: String?) {
    private var nama: String
    private var dev: String
    init {
        this.nama = nama!!
        this.dev = dev!!
    }

    fun getNama(): String? {
        return nama
    }
    fun setNama(nama: String?){
        this.nama = nama!!
    }
    fun getDev(): String? {
        return dev
    }
    fun setDev(dev: String?){
        this.dev = dev!!
    }
}